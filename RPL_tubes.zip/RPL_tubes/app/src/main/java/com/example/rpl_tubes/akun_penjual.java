package com.example.rpl_tubes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class akun_penjual extends AppCompatActivity {
    String[] daftar;
    ListView listView;
    Menu menu;
    protected Cursor cursor;
    DBhelper db;
    Button edit_profile;
    private BottomAppBar bottomAppBar;
    private BottomNavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_akun_penjual);

        bottomAppBar=findViewById(R.id.bottomBar);
        navigationView=findViewById(R.id.navigationview);
        edit_profile=findViewById(R.id.edit_info_penjual);

        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        Intent intent = new Intent(akun_penjual.this,beranda_penjual.class);
                        startActivity(intent);
                        return true;
                    case R.id.chat:
                        Toast.makeText(akun_penjual.this,"chat click",Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.akun:
                        Intent akun = new Intent(akun_penjual.this,akun_penjual.class);
                        startActivity(akun);
                        return true;
                }
                return false;
            }
        });
    }
    public void edit(View view){
        Intent intent=new Intent(this,info_penjual.class);
        String nama=getIntent().getStringExtra("nama");
        intent.putExtra("nama",nama);
        startActivity(intent);
    }

}