package com.example.rpl_tubes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class firstHome_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_home_admin);
    }
}