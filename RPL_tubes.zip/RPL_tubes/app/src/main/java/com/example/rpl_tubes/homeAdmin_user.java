package com.example.rpl_tubes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class homeAdmin_user extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_admin_user);
    }
}