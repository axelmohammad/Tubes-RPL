package com.example.rpl_tubes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.rpl_tubes.adapter.Adapter;
import com.example.rpl_tubes.adapter.cartadapter;

public class summary_activity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    public com.example.rpl_tubes.adapter.cartadapter Cartadapter;
    public static final int LOADER=0;
    TextView alamat,total_harga;
    protected Cursor cursor;
    DBhelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        Button button=findViewById(R.id.clearthedatabase);
        db=new DBhelper(this);
        alamat=findViewById(R.id.view_alamat);
        total_harga=findViewById(R.id.view_total_harga);

        SQLiteDatabase db1=db.getReadableDatabase();
        cursor=db1.rawQuery("SELECT * FROM pembeli WHERE nama='" +
                getIntent().getStringExtra("nama_user")+"'",null);
        cursor.moveToFirst();
        if (cursor.getCount()>0) {
            cursor.moveToPosition(0);
            alamat.setText(cursor.getString(4));
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int delete=getContentResolver().delete(dbcontract.orderentry.content_uri,null,null);

            }
        });

        getSupportLoaderManager().initLoader(LOADER,null,this);

        ListView listView=findViewById(R.id.list);
        Cartadapter=new cartadapter(this,null);
        listView.setAdapter(Cartadapter);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id,  Bundle args) {
        String[] projection={dbcontract.orderentry._ID,dbcontract.orderentry.kolom_nama,dbcontract.orderentry.kolom_total,dbcontract.orderentry.kolom_jumlah};
        return new CursorLoader(this,dbcontract.orderentry.content_uri,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished( Loader<Cursor> loader, Cursor data) {
        Cartadapter.swapCursor(data);

    }

    @Override
    public void onLoaderReset( Loader<Cursor> loader) {
        Cartadapter.swapCursor(null);
    }
}